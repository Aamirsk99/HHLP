# Hindivine Diet Chart Generator

## 1. Web generator (for your dashboard or website)
`web/Hindivine-Diet-Chart-Maker.html` is one self-contained file: all recipe data is inside it. Upload it to your
dashboard or website (or just open it in a browser). It needs no server and no database.

- Types of diet: General, High-Protein, Diabetes, PCOS, Thyroid, Heart-Healthy, GLP-1 Support, Liquid, Semi-Liquid,
  Bariatric Surgery (stages from the surgery day) and Allurion Balloon (stages from placement).
- Plan by calories, protein or both; vegetarian, vegan, eggetarian or non-vegetarian.
- Start date and 1-30 days; "Next N days" continues with new dishes.
- Meals per day: choose 2 to 8 meals; lunch and dinner combinations, day-wise preferences (veg, non-veg, fasting,
  light day), foods to prefer and foods to avoid.
- Every meal shows kcal, protein, carbs, fat and fibre; every day shows the totals and is checked against its targets.
- Edit menu: change portions (- / +), swap a dish for a suggestion, delete items, and "+ Add food" to any meal, either
  from suggestions, by searching all recipes and foods, or by typing your own item with its nutrition. Undo is available.
- Print / Save as PDF and Copy chart as text.
- Language menu with 20 languages: 12 Indian (Hindi, Bengali, Marathi, Telugu, Tamil, Gujarati, Kannada, Malayalam,
  Odia, Punjabi, Urdu, Assamese; dish names in the local script too) and Arabic, French, Spanish, German, Portuguese,
  Russian, Chinese, Japanese. A second-language menu shows every item in two languages (e.g. English + Hindi).

## Food list
`food-list/Hindivine-Food-List.xlsx` (also `.csv`) lists 5,958 foods with calories, protein, carbs, fat and fibre: 542 Indian
foods from IFCT 2017 (per 100 g, with Hindi names, sugar, minerals and vitamin C), 251 Hindivine ingredients (per 100 g with
household measures) and the 5,165 Hindivine dishes (per serving). Its Portion Calculator sheet gives the nutrition for any amount.

`food-list/Hindivine-Food-Finder.html` is a searchable version for your dashboard: search in English or Hindi, filter by
source, category and diet, sort by protein or calories, and add foods to "My Meal" to total a meal. Click any Hindivine
dish to open its recipe (nutrition, ingredients and steps). It has the same language and second-language menus as the
diet chart maker (recipe steps stay in English).
Rebuild both with `python3 foodlist.py OUT_FOLDER` (inside the `python` folder).

## 2. Python generators (branded PDFs)
Install Python 3.9+ and run `pip install -r requirements.txt` inside the `python` folder, then:

| What | Command |
|---|---|
| Personal GLP-1 plan for one person | `python3 personal_plan.py --name "Full Name" --age 35 --sex F --height 163 --weight 96 --diet nonveg --out plan.pdf` |
| One diet chart by protein or calories | `python3 autodiet.py --protein 120 --diet veg` or `python3 autodiet.py --kcal 1500 --diet nonveg --focus diabetes` |
| All 5,040 weight-loss charts | `python3 dietchart.py logo-small.jpg OUT_FOLDER` |
| All 580 protein charts (50-190 g) | `python3 dietchart.py logo-small.jpg OUT_FOLDER --protein` |
| All 5,165 recipe PDFs | `python3 build.py logo-small.jpg OUT_FOLDER --by-meal` |
| Rebuild the web generator after changes | `python3 webdata.py` (writes ../diet-generator/index.html) |

Main files: `dietplan.py` (meal planner), `dietchart.py` (chart PDF layout), `personal_plan.py` (personal plan),
`web_template.html` + `webdata.py` (web generator), `catalog.py` (ingredient nutrition, IFCT 2017 / USDA),
`fam*.py` (the 5,165 recipes), `render.py` (branding, fonts, Our Services page).

Fonts: Lato and DM Serif Display, SIL Open Font License (see `fonts/OFL-*.txt`).
Carbs are available carbohydrate (as in IFCT 2017); fibre is listed separately. Values are estimates; plans are general guidance and should be reviewed by a doctor or dietitian.
